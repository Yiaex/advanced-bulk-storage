"""Verify the advanced_bulk_storage v3 texture set.

    python verify_textures.py                     # checks src/main/resources by default
    python verify_textures.py --root <dir>        # checks any textures/ dir
    python verify_textures.py --root . --no-manifest

Checks, in order:
  1. all 28 expected filenames exist
  2. every file is 16x16 RGBA
  3. block textures are fully opaque (no alpha=0 pixel)
  4. the four cells share one identical alpha mask (they are one traced silhouette)
  5. sha256 matches MANIFEST.sha256 next to this script (optional)

Exit code 0 = everything passed.
"""

from __future__ import annotations

import argparse
import hashlib
import sys
from pathlib import Path

from PIL import Image

ITEMS = [
    "tag_bulk_storage_cell",
    "advanced_tag_bulk_storage_cell",
    "mod_bulk_storage_cell",
    "quantum_bulk_storage_cell",
    "extended_tag_card",
    "multi_compression_card",
    "storage_limit_card",
    "energy_saving_card",
    "auto_sorting_card",
    "advanced_auto_sorting_card",
    "overclocked_auto_sorting_card",
    "quantum_auto_sorting_card",
]
BLOCKS = [
    "backplane",
    "bulk_storage_interface",
    "bulk_storage_interface_online",
    "advanced_bulk_storage_interface",
    "advanced_bulk_storage_interface_online",
    "bulk_storage_migrator_side",
    "bulk_storage_migrator_top",
    "overclocked_bulk_storage_migrator_side",
    "overclocked_bulk_storage_migrator_top",
    "quantum_bulk_storage_migrator_side",
    "quantum_bulk_storage_migrator_top",
    "bulk_storage_drive",
    "advanced_cell_workbench",
    "bulk_storage_manager",
    "bulk_storage_monitor",
    "bulk_storage_monitor_signal",
]
CELLS = ITEMS[:4]


def alpha_mask(img: Image.Image) -> bytes:
    return img.convert("RGBA").tobytes()[3::4]


def main() -> int:
    here = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default="src/main/resources/assets/advanced_bulk_storage/textures")
    parser.add_argument("--no-manifest", action="store_true")
    args = parser.parse_args()

    root = Path(args.root)
    failures: list[str] = []
    print(f"root: {root.resolve()}")

    if not root.is_dir():
        print(f"FAIL: no such directory: {root}")
        return 2

    for kind, names in (("item", ITEMS), ("block", BLOCKS)):
        for name in names:
            path = root / kind / f"{name}.png"
            if not path.exists():
                failures.append(f"missing: {kind}/{name}.png")
                continue
            img = Image.open(path)
            if img.size != (16, 16):
                failures.append(f"{kind}/{name}.png size={img.size} (want 16x16)")
            if img.mode != "RGBA":
                failures.append(f"{kind}/{name}.png mode={img.mode} (want RGBA)")
            if kind == "block" and min(img.convert("RGBA").tobytes()[3::4]) != 255:
                failures.append(f"{kind}/{name}.png has transparent pixels (blocks must be opaque)")

    found = sum(1 for k, ns in (("item", ITEMS), ("block", BLOCKS))
                for n in ns if (root / k / f"{n}.png").exists())
    print(f"files: {found}/28")

    masks = {}
    for name in CELLS:
        path = root / "item" / f"{name}.png"
        if path.exists():
            masks[name] = alpha_mask(Image.open(path))
    if len(masks) == len(CELLS):
        opaque = sum(1 for b in masks[CELLS[0]] if b)
        if len(set(masks.values())) != 1:
            failures.append("the four cells do not share one alpha mask")
        if opaque != 150:
            failures.append(f"cell alpha mask has {opaque} opaque px (AE2 trace is 150)")
        print(f"cell alpha mask: {opaque} opaque px, identical across 4: {len(set(masks.values())) == 1}")

    manifest = next((p for p in (here / "MANIFEST.sha256", here.parent / "MANIFEST.sha256")
                     if p.exists()), None)
    if not args.no_manifest and manifest is not None:
        # manifest paths are relative to the package root; only the trailing
        # "<kind>/<name>.png" matters, so the same manifest also works against
        # the mod's src/main/resources tree.
        bad = 0
        checked = 0
        for line in manifest.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line:
                continue
            digest, rel = line.split(maxsplit=1)
            parts = rel.replace("\\", "/").split("/")
            if len(parts) < 3:
                continue
            path = root / parts[-2] / parts[-1]
            if not path.exists():
                continue
            checked += 1
            if hashlib.sha256(path.read_bytes()).hexdigest() != digest:
                bad += 1
        if bad:
            print(f"manifest: {bad}/{checked} file(s) differ (expected if you re-rendered)")
        else:
            print(f"manifest: all {checked} hashes match")

    if failures:
        print(f"\nFAIL ({len(failures)})")
        for item in failures:
            print("  -", item)
        return 1
    print("\nOK: 28/28")
    return 0


if __name__ == "__main__":
    sys.exit(main())
