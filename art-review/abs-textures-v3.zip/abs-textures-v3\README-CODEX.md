# advanced_bulk_storage 贴图包 v3 —— 交接说明

这是一套已经定稿的物品 + 方块贴图（28 张 16×16 PNG），以及生成它们用的脚本。
目标仓库：`D:\Users\逸\Desktop\mods_dev\advanced-bulk-storage`（NeoForge 1.21.1，mod id `advanced_bulk_storage`）。

任务分两步：**先把这 28 张替换进资源目录**，然后在此基础上继续优化。

---

## 1. 目录内容

```
abs-textures-v3/
├── assets/advanced_bulk_storage/textures/
│   ├── item/   12 张（4 元件 + 8 升级卡）
│   └── block/  16 张
├── tools/
│   ├── draw_assets_v3.py    生成器（唯一真源，改这里重渲染）
│   ├── v3_sheets.py         对比图 / 总览图 / 细节图 / 1×-2×-3× 检查图
│   └── verify_textures.py   校验脚本（尺寸、alpha、sha256）
├── sheets/                  评审用图（仅参考，不要发布进 jar）
├── MATERIAL-SPEC.md         完整材质规格（调色板、逐张贴图说明、映射表）
└── MANIFEST.sha256          28 张 PNG 的 sha256
```

**文件名与现有资源完全一致**，覆盖即可，不需要改模型 JSON，也不需要改 blockstate。

环境要求：脚本用 Pillow（`pip install pillow`），Python 3.10+。
如果只是为了换贴图，连 Pillow 都不需要——直接拷 PNG 就行。

---

## 2. 安装（把贴图换进去）

目标目录：`src/main/resources/assets/advanced_bulk_storage/textures/`

PowerShell：

```powershell
$dst = "src\main\resources\assets\advanced_bulk_storage\textures"
Copy-Item -Recurse -Force "assets\advanced_bulk_storage\textures\*" $dst
```

或 bash：

```bash
cp -r assets/advanced_bulk_storage/textures/* src/main/resources/assets/advanced_bulk_storage/textures/
```

或者直接用生成器自带的安装命令（前提是把 `tools/draw_assets_v3.py` 放到仓库的 `tools/` 下）：

```bash
python tools/draw_assets_v3.py --install
```

装完校验：

```bash
python tools/verify_textures.py --root src/main/resources/assets/advanced_bulk_storage/textures
```

期望输出：`28/28 ok`，四个元件的 alpha 掩码一致。

---

## 3. 硬约束（优化时不要破坏）

| 项 | 要求 |
| --- | --- |
| 尺寸 | 全部 16×16，RGBA |
| 文件名 | 不能改（模型 JSON 与 blockstate 按文件名引用） |
| 元件轮廓 | 逐像素等于 AE2 `item_storage_cell_1k` 的 alpha 掩码（150 个不透明像素）。**不要改形状** |
| 方块透明 | 方块贴图必须整块不透明（`textures/block/*` 不能有 alpha=0 像素） |
| 不可见像素 | alpha=0 的像素一律写 `(0,0,0,0)`，不要像 AE2 那样留残色 |
| 模型 / blockstate | 本次不改；`build/resources/main/` 里是 gradle 生成的旧副本，不要手改 |

---

## 4. 元件是「AE2 结构 + MEGA Cells 材质」

四张元件不是手绘的，是逐像素搬的：

- **轮廓 / 切面明暗 / 描边**：来自 AE2 `item_storage_cell_1k.png`，一个像素没动。
- **外壳 116 像素**：来自 MEGA Cells 4.11.0 的 `bulk_item_cell.png`，同一坐标取色（两张贴图 alpha 掩码完全一致）。
- **内芯 34 像素**：本模组的等级色。

壳色映射表（AE2 → MEGA bulk）：

```
#f2f2f2 → #737173    #dedfe3 → #5a575a    #cbccd4 → #4d494d
#adb0c4 → #3b393b    #9a9fb4 → #4c4143    #878fa5 → #3c3232
#696d88 → #31292a    #4d4d67 → #271c1d    #413f54 → #111111
```

核色（`tier.base` / `tier.light` / `tier.glow`，分别替换 AE2 的 `#2d69e1` / `#3894ff` / `#40c1ff`）：

| 元件 | 内芯三色 |
| --- | --- |
| `tag_bulk_storage_cell` | `#1c919a` / `#1aa9a7` / `#20c5b5` |
| `advanced_tag_bulk_storage_cell` | `#7da9d2` / `#9cd3ff` / `#daffff` |
| `mod_bulk_storage_cell` | `#dc9613` / `#e9b115` / `#fad64a` |
| `quantum_bulk_storage_cell` | `#8f6fc4` / `#a98fd8` / `#c9aee8` |

生成器里三套壳色都保留，可随时切换：

```bash
python tools/draw_assets_v3.py          # 默认：MEGA bulk 色壳（即本包）
python tools/draw_assets_v3.py ae2      # AE2 原版银壳
python tools/draw_assets_v3.py dark     # MEGA mega_item_cell_housing 近黑壳
```

---

## 5. 方块沿用 AE2 机壳分层

所有机器面共用同一套 AE2 `io_port` 质感（`casing()` 函数）：

```
第 0 行    #f2f2f2  顶部亮边
第 1 行    #d5d6dc  凹槽
第 2–11 行 #dedfe3  面板 + 内嵌凹槽（2,2)-(13,11)，凹槽底色 #b3b6c6
第 12 行   #cbccd4  接缝
第 13 行   下层板 + 4 个通风孔（x=4,7,10,13）
第 14–15 行 深色底边 #787e97
```

**没有**粗亮边框、没有四角铆钉——这两样是 v2 的问题，AE2 原版机壳是「一条亮顶边 + 一条凹槽 + 大面积平脸」。

各面差异只在凹槽里的内容：接口是亮条端口，迁移器是双轨 + 箭头/处理器/量子环，驱动器是四个插槽，工作台是元件座 + 工具轨，管理器是 3×3 模块，监视器是深色屏幕 + 走线 + 红石指示灯。

---

## 6. 继续优化的候选方向（按性价比排序）

1. **升级卡也做逐像素对齐**（收益最大）。目前 8 张卡是手绘的 AE2 风格卡身。AE2 的 `basic_card.png` / `advanced_card.png` 卡身是纯灰、没有功能图案，直接照搬会让 8 张卡长得一样。建议做法：卡身几何逐像素抄 `basic_card`，把功能记号画在 AE2 卡面那块空区域里。需要先确认「要不要保留功能记号」。
2. **内芯提亮到 MEGA 的饱和度**。MEGA 的 1m 内芯是 `#ffcf40` / `#fff373` / `#faffbf`；我们的四个核色偏中等亮度，在深色壳上稍微闷。只改三个颜色值，几何不动。改完注意四张卡/方块的强调色是否也要跟着换（`Tier` 同时用于卡片边缘触点和方块导轨）。
3. **离线态去饱和**。`bulk_storage_interface`（离线）现在是灰端口，`_online` 是亮蓝端口。如果要更强的「断电感」，可以把离线版的整体色相往 `DESAT` 拉，而不是只改端口。
4. **监视器屏幕**。现在是一条折线 + 网格。如果要显示真实容量的柱状/阶梯图，屏幕区是 `(4,3)-(11,8)` 共 8×6，能放 8 根 1px 柱子。
5. **32×32 高清版**。不建议现在做：文件名相同会被引擎按 16×16 采样逻辑引用，需要额外的 `textures/` 分辨率资源包机制。

---

## 7. 参考来源

- AE2 贴图：从 `ae2-7Ac6mXbf.jar`（1.21.1）解出，仅用于反推造型与材质。
- MEGA Cells 贴图：从 MEGA Cells 4.11.0 jar 解出，仅用于取壳色。

这两套第三方贴图**没有**打进本包，也不要提交进仓库或打进 jar。本包只包含我们自己画的 28 张成品。

---

## 8. 已知取舍

- 元件现在是深色壳 + 亮内芯，在深色 GUI 背景上主要靠**内芯色相**区分等级，这和 MEGA 实机一样；如果觉得四个等级不够好认，请走「第 6 节第 2 条」提亮核色，不要改轮廓。
- 方块与卡片是浅色 AE2 灰，元件是深色——这个明暗对比是有意的（AE2 生态里 MEGA 元件就是深色小块）。
